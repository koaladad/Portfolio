﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardExercise1
{
    public enum Suit {  Spades = 0, Diamonds = 1, Clubs = 2, Hearts = 3 };

    public enum Rank {  Two = 2, Three = 3, Four = 4, Five = 5, Six = 6,
                        Seven = 7, Eight = 8, Nine = 9, Ten = 10, Jack = 11, Queen = 12, King = 13, Ace = 14 };

    public class Card : IComparable
    {
        public Suit _suit { get; set; }
        public Rank _rank { get; set; }

        //Ctor - using enums
        public Card(Suit suit, Rank rank)
        {
            _suit = suit;
            _rank = rank;
        }

        //Ctor - using int
        public Card(int suit, int rank)
        {

            if (Enum.IsDefined(typeof(Suit), suit))
            {
                Suit suitEnum = (Suit)suit;
                _suit = suitEnum;
            }
            else
            {
                throw new Exception("Invalid suit entered for Card Constructor, must be 0-3");
            }

            if (Enum.IsDefined(typeof(Rank), rank))
            {
                Rank rankEnum = (Rank)rank;
                _rank = rankEnum;
            }
            else
            {
                throw new Exception("Invalid rank entered for Card Constructor, must be 2-14");
            }
        }

        #region Operator Overloads and CompareTo(Sort)
        public int CompareTo(Object obj)
        {
            if (obj == null) return 1;

            Card other = obj as Card;

            // Sort by Suit, then by rank
            return Comparison(this, other);

        }

        public static bool operator <(Card card1, Card card2)
        {
            return Comparison(card1, card2) < 0;
        }

        public static bool operator >(Card card1, Card card2)
        {
            return Comparison(card1, card2) > 0;
        }

        public static bool operator ==(Card card1, Card card2)
        {
            return Comparison(card1, card2) == 0;
        }

        public static bool operator !=(Card card1, Card card2)
        {
            return Comparison(card1, card2) != 0;
        }

        public static bool operator <=(Card card1, Card card2)
        {
            return Comparison(card1, card2) <= 0;
        }

        public static bool operator >=(Card card1, Card card2)
        {
            return Comparison(card1, card2) >= 0;
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            throw new Exception("Sorry, I don't know what GetHashCode should do here.");
        }

        public static int Comparison(Card card1, Card card2)
        {
            if (card1._suit < card2._suit)
            {
                return -1;
            }
            else if (card1._suit == card2._suit)
            {
                //same suit, compare rank
                if (card1._rank < card2._rank)
                {
                    return -1;
                }
                else if (card1._rank == card2._rank)
                {
                    return 0;
                }
                else if (card1._rank > card2._rank)
                {
                    return 1;
                }
            }
            else if (card1._suit > card2._suit)
            {
                return 1;
            }

            return 0;
        }
        #endregion

        public void PrintCard()
        {
            Console.WriteLine($"{_rank} of {_suit}");
        }
    }
}
