﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace CardExercise1
{
    class Deck
    {
        List<Card> deck = new List<Card>();

        public Deck()
        {
            for (int i = 0; i <= 3; ++i)
            {
                for (int j = 2; j <= 14; ++j)
                {
                    deck.Add(new Card(i, j));
                }
            }
        }

        public List<Card> GetDeck()
        {
            return deck;
        }

    }
}
