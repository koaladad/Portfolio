import os
from random import *

def ask_question(data_array):
	random_var = randrange(0,len(data_array))
	question = data_array[random_var][0]
	answer = data_array[random_var][1]

	input_value = input("What is the russian word for " + repr(question) + "? ")

	#hi
	#Correct Answer
	if (input_value == answer):
		print ("CORRECT.")
		return True
	else:
		print("WRONG. The correct answer is " + answer)
		return False

def clear_screen():
	os.system('cls')

def wait_to_continue():
	os.system("pause")