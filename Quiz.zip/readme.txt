This is a quiz in unicode format, can be done in different languages

run from_text.py
enter text.txt and follow format in text file